# Enumerations

TODO
