# Memory Model

TODO
