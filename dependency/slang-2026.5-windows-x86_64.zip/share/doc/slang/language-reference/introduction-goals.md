# Slang Language Goals

TODO
